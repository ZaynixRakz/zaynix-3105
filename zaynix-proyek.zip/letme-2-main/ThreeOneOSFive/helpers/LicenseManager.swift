import Foundation
import UIKit

class LicenseManager: ObservableObject {
    @Published var isLicenseValid = false
    @Published var isBusy = false
    @Published var message: String? = nil
    @Published var rememberKey = true
    @Published var contactOwner: String? = "@ZAYNIX_OWNER"
    
    init() {
        // Logika inisialisasi bawaan
    }
    
    func getDeviceHWID() -> String {
        return UIDevice.current.identifierForVendor?.uuidString ?? "UNKNOWN_HWID"
    }
    
    func activate(key: String) {
        self.isBusy = true
        self.message = nil
        
        let deviceHWID = self.getDeviceHWID()
        
        // Silakan ganti domain-vercel-anda dengan domain Vercel API Anda yang asli
        let vercelURLString = "https://zaynix-apiu.vercel.app/api/check?key=\(key)&hwid=\(deviceHWID)"
        
        guard let url = URL(string: vercelURLString) else { 
            self.isBusy = false
            return 
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                self.isBusy = false
                if let data = data {
                    if let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                        let status = json["status"] as? String ?? "FAILED"
                        let expiryTime = json["expired"] as? String ?? ""
                        
                        if status == "SUCCESS" {
                            // Kunci VALID dan HWID COCOK! Menu ZAYNIX terbuka
                            self.isLicenseValid = true
                            self.message = "Masa Aktif: \(expiryTime)"
                        } else {
                            // Kunci SALAH, HWID BERBEDA, atau WAKTU HABIS! Aplikasi tetap terkunci
                            self.message = json["message"] as? String ?? "Kunci tidak valid atau sudah digunakan di device lain!"
                        }
                    }
                } else {
                    self.message = "Gagal terhubung ke Server ZAYNIX!"
                }
            }
        }.resume()
    }
}
